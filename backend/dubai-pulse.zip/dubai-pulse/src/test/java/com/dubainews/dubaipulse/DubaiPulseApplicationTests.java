package com.dubainews.dubaipulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DubaiPulseApplicationTests {

	@Test
	void contextLoads() {
	}

}
