package com.dubainews.dubaipulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DubaiPulseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DubaiPulseApplication.class, args);
	}

}
